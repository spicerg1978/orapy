select sample_time, session_id, session_serial#, sql_id, event, wait_class, wait_time, blocking_session, time_waited, module
from dba_admin.ACTIVE_SESSION_HIST_20121220
where sample_time between '20-DEC-12 05.05.00.000 PM'
  and '20-DEC-12 05.30.00.209 PM'
order by SAMPLE_TIME
/
