drop index tmp_pka_delete_idx;
