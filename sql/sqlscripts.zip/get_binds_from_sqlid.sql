select
sql_id,
b.name BIND_NAME,
b.value_string BIND_STRING
from
v$sql t
join v$sql_bind_capture b
using (sql_id)
where
b.value_string is not null
and sql_id='8r3jb6qw9juub';




WITH /* PTI [search] HalfTradeSearch */ querywith  AS (SELECT :trading_day           AS trading_day         , :to_trading_day         AS to_trading_day , :position_day          AS position_day        , :to_position_day        AS to_position_day , :note_creation_day     AS note_creation_day   , :to_note_creation_day   AS to_note_creation_day , :tender_deletion_day   AS tender_deletion_day , :to_tender_deletion_day AS to_tender_deletion_day , :status_group          AS status_group , :operator_group        AS operator_group , :exchange_code         AS exchange_code , :trading_day_component AS trading_day_component , :default_firm          AS default_firm , :max_result_count      AS max_result_count FROM dual) , refdata    AS (SELECT (psm.trading_day) AS trading_day FROM pti_system_mode psm, querywith qw WHERE psm.exchange_code = qw.exchange_code AND psm.system_mode_group = 'DEF') , opgrpfirms AS (SELECT firm FROM operator_group og, querywith qw, refdata rd WHERE og.trading_day = rd.trading_day    AND og.exchange_code = qw.exchange_code AND og.group_name  = qw.operator_group AND firm != qw.default_firm) SELECT ht_search.* FROM ( SELECT   0  AS display_row_num , 'U' AS pti_action_flag , ht.trading_day , ht.exchange_code , ht.half_trade_id , ht.sub_trade_seq_no , ht.half_trade_uid , ht.parent_uid , ht.countertrade_id , ht.countertrade_uid , ht.counterclaim_id , ht.counterclaim_uid , ht.object_version , ht.trade_status , ht.traded_date , ht.customer_ref , ht.slip_type , ht.trade_type_ind , ht.trade_type , ht.wholesale_trade_type , ht.strategy_code , ht.buy_sell_ind , ht.originator_firm , ht.originator_trader , ht.originator_clearer , TRIM(ht.counterparty_firm)   AS counterparty_firm , TRIM(ht.counterparty_trader) AS counterparty_trader , ht.physical_commodity , ht.logical_commodity , ht.expiry_date , ht.contract_type , ht.exercise_price , ht.trade_price , ht.volume , ht.remaining_volume , ht.account_code , TRIM(ht.allocation_firm)   AS allocation_firm , TRIM(ht.allocation_trader) AS allocation_trader , ht.cross_type , TRIM(ht.open_close_ind)    AS open_close_ind , ht.trade_clip_id , ht.order_id , ht.user_info , ht.trader_card_ref , ht.sub_account , ht.order_slip_id , ht.venue_type , ht.trade_publish_ind , ht.kerb_trade_ind , ht.kerb_tree_ind , ( SELECT cc.flex_contract_ind FROM commodity_contract cc WHERE cc.trading_day           = rd.trading_day AND cc.exchange_code         = ht.exchange_code AND cc.physical_commodity    = ht.physical_commodity AND cc.generic_contract_type = ht.generic_contract_type )             AS flex_contract_ind , ht.transfer_ind , ( SELECT cc.options_style FROM commodity_contract cc WHERE cc.trading_day           = rd.trading_day AND cc.exchange_code         = ht.exchange_code AND cc.physical_commodity    = ht.physical_commodity AND cc.generic_contract_type = ht.generic_contract_type )             AS exercise_style , ( SELECT CASE WHEN cc.cash_settled_ind = 'Y' THEN 'C' ELSE 'P' END FROM commodity_contract cc WHERE cc.trading_day           = rd.trading_day AND cc.exchange_code         = ht.exchange_code AND cc.physical_commodity    = ht.physical_commodity AND cc.generic_contract_type = ht.generic_contract_type )             AS delivery_style , CASE WHEN ht.trade_locked_ind = 'N' THEN NULL ELSE ht.trade_locked_ind END AS trade_locked_ind  FROM half_trade         ht , querywith          qw , refdata            rd , commodity_contract cc  WHERE ht.exchange_code = qw.exchange_code AND ht.originator_firm IN ( SELECT firm FROM operator_group og WHERE og.trading_day   = qw.trading_day AND og.exchange_code = qw.exchange_code AND og.group_name    = qw.operator_group AND og.firm         != qw.default_firm ) AND (ht.trading_day = qw.trading_day) AND (ht.trade_status IN (SELECT slip_status FROM status_group WHERE group_type = 'TRADE' AND group_name = qw.status_group)) ORDER BY trading_day asc, exchange_code asc, half_trade_id asc  ) ht_search, querywith WHERE ROWNUM <= querywith.max_result_count + 1 




f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :OPERATOR_GROUP
LIF$DEFAULT

f5380w0m4m6cu :OPERATOR_GROUP
LIF$DEFAULT

f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :TRADING_DAY
008067

f5380w0m4m6cu :OPERATOR_GROUP
GHF$DEFAULT

f5380w0m4m6cu :OPERATOR_GROUP
GHF$DEFAULT



8r3jb6qw9juub