column ROWLABEL format A15

-- Used for the SHOW ERRORS command
column LINE/COL format A8
column ERROR    format A65  WORD_WRAPPED

-- Used for the SHOW SGA command
column name_col_plus_show_sga format a24

-- Defaults for SHOW PARAMETERS
column name_col_plus_show_param format a36 heading NAME
column value_col_plus_show_param format a30 heading VALUE

-- For backward compatibility

-- Defaults for SET AUTOTRACE EXPLAIN report
column id_plus_exp format 990 heading i
column parent_id_plus_exp format 990 heading p
column plan_plus_exp format a100
column object_node_plus_exp format a8
column other_tag_plus_exp format a29
column other_plus_exp format a44

-- column values for dbls
column object_type format a20
column object_name format a35
column tablespace_name format a30

set appinfo ON 
set arraysize 2000
set autocommit OFF
set autoprint OFF
set autorecovery OFF
set autotrace OFF
set blockterminator "."
btitle OFF
set cmdsep OFF
set colsep " "
set compatibility NATIVE
set concat "."
set copycommit 0
set COPYTYPECHECK ON
set describe DEPTH 1 LINENUM ON INDENT ON
set markup HTML OFF SPOOL OFF ENTMAP ON PREFORMAT OFF
set echo OFF
set editfile "sql_buffer.sql"
set embedded OFF
set escape OFF
set FEEDBACK ON
set flagger OFF
set flush ON
set heading ON
set headsep "|"
rem pages size 131 for telnet clients
set linesize 132
set loboffset 1
set long 5000
set longchunksize 80
set newpage 1
set null ""
set numformat ""
set numwidth 10
set pagesize 9999
set PAUSE OFF
set pno 20
set recsep WRAP
set recsepchar " "
repfooter OFF
repheader OFF
set serveroutput ON SIZE 100000
set shiftinout INVISIBLE
set showmode OFF
set sqlblanklines OFF
set sqlcase mixed
set sqlcontinue "> "
set sqlnumber ON
set sqlprefix "#"
set sqlterminator ";"
set suffix "sql"
set termout ON
set time OFF
set timing OFF
set trimout ON
set trimspool ON
ttitle OFF
set underline "-"
set verify ON
set wrap on
set termout off pause off
rem 
rem Store username 
rem 
col user_id new_value user_id 
col user_name new_value user_name 
select user_id, lower(username) user_name from user_users 
  where username = user
;
rem 
rem Store database name 
rem 
col db_name new_value db_name 
select lower(substr(global_name,1,(instr(global_name,'.',1,2)-1))) 
db_name from global_name;
--select instance_name||'.'||host_name db_name
--from v$instance
;

set sqlprompt "&user_name@&db_name> "
set termout on

col version format a15
col status format a40
col product format a45
set heading off
set feedback off
select * from product_component_version;
Prompt
set heading on
set feedback on
#define _EDITOR = "C:\Program Files\TextPad 4\TextPad.exe"
