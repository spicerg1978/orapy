select USERNAME "User",
       count(*) "connects"
  from user_audit group by rollup(username);