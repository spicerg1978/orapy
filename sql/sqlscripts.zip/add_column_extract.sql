 set lines 1000 pages 1000
 set feedback off
 prompt *************************************************
 prompt *	add_column_extract script	        *
 prompt *************************************************
 
 prompt
  ACCEPT own CHAR PROMPT    "Enter Table Owner: "
 prompt
 
 select distinct table_name
  from  conf
 where  table_owner = '&own';
 
 prompt
  ACCEPT tab CHAR PROMPT    "Enter Table Name: "
 prompt
 
prompt 
 ACCEPT col CHAR PROMPT     "Enter Column Name: "
prompt 

variable v_cnt number;
variable v_ord number;


begin

select count(*) into :v_cnt
  from conf
 where table_owner = '&own'
   and table_name = '&tab'
   and table_column = '&col';
   
   
if :v_cnt > 0 
then
	sys.dbms_output.put_line('Column already exists in table will update extract to  Y ');
	update conf
	   set extract = 'Y'
	 where table_owner = '&own'
	   and table_name = '&tab'
	   and table_column = '&col';
	   
	commit;
else
        sys.dbms_output.put_line('Column does not exist, will insert this new record');
        
        select max(col_num) into :v_ord
          from conf
         where table_owner = '&own'
           and table_name = '&tab';
           
        insert into conf
        values
        ('&own','&tab','&col',:v_ord+1, 'Y');
        
        commit;
        
        sys.dbms_output.put_line('Remember this new column has been added to the end of the extract');
        
end if;
end;
/

select *
  from conf
 where table_owner = '&own'
   and table_name = '&tab'
order by col_num;



 