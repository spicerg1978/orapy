
Prompt Enter the sid and serial# of the session that you wish to kill...

set lines 1000
column osuser format a13
column username format a15
column machine format a25
column login format a20
column module format a25
column action format a35
column client_info format a20
column sid format 9999
column serial# format 99999

select username, osuser, status, machine, sid, serial#,
       to_char(logon_time, 'YYYY-MM-DD HH24:MI:SS') "LOGIN", 
       module, action, client_info
  from v$session
 where username is not null
 and sid != (select distinct sid from v$mystat)
 and status = 'ACTIVE'
 order by logon_time
/

set verify off

alter system kill session '&sid,&session'
;

