select /*+ FIRST_ROWS (100) */ * 
from
(select * from tscs_audit 
where 
         exchange_code = :exchange_code
     and trading_day = :trading_day
     and output_sequence_no > :output_sequence_no
     and message_type in ('V058', 'V111', 'V105', 'V110', 'V120')
     /*and trs_osn not in (92086,92088,93054)*/
order by trading_day, exchange_code, output_sequence_no)
where rownum < 1001
