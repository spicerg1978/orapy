set heading off feedback off lines 500 verify off
prompt set feedback on 
select 'alter system kill session '||''''||sid||','||serial#||''''||';'
from v$session 
where username =UPPER('&1') AND STATUS != 'KILLED';

