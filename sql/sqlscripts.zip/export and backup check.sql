#!/usr/bin/ksh
#################################################################################
# export_check.ksh                                                              #
#   Written By: Gareth Spicer                                                   #
#   Date:       03 June 2011                                                    #
#   Purpose:    Purpose of the script is to checki that the clearing run has    #
#               completed on trident for all                                    #
#               3 exchanges before we take the schema export                    #
#                                                                               #
#################################################################################
# History                                                                       #
# 03-06-2011    Initial Design                                                  #
#                                                                               #
#################################################################################
. $HOME/.profile
counter=1
delay=51
limit=5
usr=$1
passwd=$2
export ORACLE_SID=$3

        echo "**********************************************************"
        echo "checking if clearing has completed for all exchanges"

trddy=`sqlplus -s $usr/$passwd@$ORACLE_SID <<EOF | sed 's/-//'| sed 's/PL\/SQL procedure successfully completed.//'
set serveroutput on
             set heading off
             DECLARE
                v_trad varchar(10);
             BEGIN
                v_trad := 0;
                select '-'||trading_day into v_trad
                  from trading_calendar
                 where to_char(todays_date, 'yyyymmdd') = (
                           select max(to_char(todays_date, 'yyyymmdd')) dt
                             from trading_calendar
                            where trunc(todays_date) <= trunc(sysdate));
             dbms_output.put_line(v_trad);
             END;
             /
             exit
             EOF`

echo "Current Trading Day is : $trddy"

while [[ $counter -lt $delay ]]; do
cnt=`sqlplus -s $usr/$passwd@$ORACLE_SID <<EOF | sed 's/-//'| sed 's/PL\/SQL procedure successfully completed.//'
             set serveroutput on
             set heading off
             DECLARE
                v_cnt varchar2(1000);
             BEGIN

                v_cnt := 0;

                select '-'||count(*) INTO v_cnt
                  from tridlive.system_mode
                 where system_mode = 'NOP'
                   and trading_day = $trddy +1;

                dbms_output.put_line(v_cnt);
             END;
             /
             exit
             EOF`


         if [[ $cnt == $limit ]]; then
              echo "=========================================================="
              date
              echo "Clearing completed on all exchanges"
              
              echo "Export job will be started....."
              /local/oracle/DBA/bin/expdb -d $ORACLE_SID -r 3 -f
              echo "Export completed successfully...."
              
              echo "Hot backup will be started....."
              /local/oracle/DBA/bin/rmbackup -d $ORACLE_SID -t HOT -r 3
	      echo "Hot Backup completed successfully...."

              date
              echo "=========================================================="
              echo "**********************************************************"
              exit
         fi

        ((counter+=1))

        date
        echo "Clearing run has only completed on $cnt exchanges $limit"
        sleep 600
done

echo "FAILED TO COMPLETE AS CLEARING HAD FINISHED ON ALL 3 EXCHANGES!"
echo "**********************************************************"

