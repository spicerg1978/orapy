 select ss.snap_id, ss.instance_number node, begin_interval_time, sql_id, plan_hash_value,
    nvl(executions_delta,0) execs,
    (elapsed_time_delta/decode(nvl(executions_delta,0),0,1,executions_delta))/1000000 avg_etime,
    (buffer_gets_delta/decode(nvl(buffer_gets_delta,0),0,1,executions_delta)) avg_lio,
    (rows_processed_delta/decode(nvl(rows_processed_delta,0),0,1,executions_delta)) avg_rows_proc,
    IOWAIT_DELTA,DISK_READS_DELTA
    from DBA_HIST_SQLSTAT S, DBA_HIST_SNAPSHOT SS
    where sql_id = '9z93w0kwgtvg9'
    and ss.snap_id = S.snap_id
    and ss.instance_number = S.instance_number
    and executions_delta > 0
   order by 1, 2, 3
   /




SQL> select * from (
SELECT a.snap_id, a.sql_id , a.session_id,
COUNT(*) OVER (PARTITION BY a.blocking_session,a.user_id ,a.program) cpt, ROW_NUMBER() OVER (PARTITION BY a.blocking_session,a.user_id ,a.program
 order by blocking_session,a.user_id ,a.program ) rn,
      a.blocking_session,a.user_id ,a.program, s.sql_text
 FROM sys.WRH$_ACTIVE_SESSION_HISTORY a ,sys.wrh$_sqltext s
where a.sql_id=s.sql_id
   and blocking_session_serial# <> 0
   and a.user_id <> 0
   --and a.sample_time > sysdate - 10
   and a.snap_id = '6144'
   ) where rn = 1
order by 3;




select * from table(dbms_xplan.display_awr('9z93w0kwgtvg9'));


set lines 200
set pagesize 1024
col parsing_schema_name format a12;
col sql_profile format a30; 
col id format a15; 
col Profplan format a30; 
col load format a16;
col active format a19;
select sql_id||'/'||child_number as Id, plan_hash_value as Plan,
substr(trim(' ' from sql_text),instr(trim(' ' from sql_text),'EXCHANGE_CODE=')+15,1) as EXchg,
--(case when SQL_PLAN_BASELINE is NULL then sql_profile else sQL_PLAN_BASELINE end) as ProfPlan,
--to_char(to_date(last_load_time,'yyyy-mm-dd/hh24:mi:ss'),'dd-mm-yyyy hh24:mi') as Load,
to_char(last_active_time,'dd-mm-yyyy hh24:mi:ss')as Active, executions, cpu_time/1000 as cpums,
ELAPSED_TIME/1000 as ElapseMs,
--(case  when executions > 0 then round((cpu_time/1000)/executions,3) else 0 end) as AVgCMs,
(case  when executions > 0 then round((ELAPSED_TIME/1000)/executions,3) else 0 end) as AVgEMs,
disk_reads, buffer_gets, rows_processed,
concurrency_wait_time cc,is_bind_sensitive S,is_bind_aware a
from V$sql
where sql_id = '5z9k8zhga8t40'
--to_char(last_active_time,'dd-mm-yyyyhh24') = '04-02-201103'
and parsing_schema_name in ('TRIDCURR','TRIDLIVE','TRIDPERF2','DOUGA')
order by last_active_time
/


select * from table(dbms_xplan.display_cursor('5z9k8zhga8t40',1));