sqlplus "/ as sysdba"
 
SQL*Plus: Release 11.1.0.7.0 - Production on Thu Nov 13 15:06:15 2008
 
Copyright (c) 1982, 2008, Oracle.  All rights reserved.
 
 
Connected to:
Oracle Database 11g Enterprise Edition Release 11.1.0.7.0 - Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options
 
set echo on
----------------------------------------------------------------------------------------
--
-- File name:   parms.sql
--
-- Purpose:     Display parameters and values.
--
-- Author:      Kerry Osborne
--
-- Usage:       This scripts prompts for three values, all of which can be left blank.
--
--              name: the name (or piece of a name) of the parameter(s) you wish to see
--
--              isset: "TRUE" or "T" to see only nondefault parameters
--
--              show_hidden: "Y" to show hidden parameters as well
--
---------------------------------------------------------------------------------------
set lines 155
col name for a50
col value for a70
col isdefault for a8
col ismodified for a10
col isset for a10

select name, value, isdefault, ismodified, isset
  from
     (
     select flag,name,value,isdefault,ismodified,
            case when isdefault||ismodified = 'TRUEFALSE' then 'FALSE' else 'TRUE' end isset
     from
        (
         select
               decode(substr(i.ksppinm,1,1),'_',2,1) flag
               , i.ksppinm name
               , sv.ksppstvl value
               , sv.ksppstdf  isdefault
               , decode(bitand(sv.ksppstvf,7),1,'TRUE',4,'TRUE','FALSE') ismodified
          from x$ksppi  i
               , x$ksppsv sv
         where i.indx = sv.indx
        )
    )
where name like nvl('%&parameter%',name)
  and upper(isset) like upper(nvl('%&isset%',isset))
  and flag not in (decode('&show_hidden','Y',3,2))
order by flag,replace(name,'_','')
/


Enter value for parameter: read_count
Enter value for isset: 
Enter value for show_hidden: Y
 
NAME                                               VALUE                                                                  ISDEFAUL ISMODIFIED ISSET
-------------------------------------------------- ---------------------------------------------------------------------- -------- ---------- ----------
db_file_multiblock_read_count                      128                                                                    TRUE     FALSE      FALSE
_db_file_exec_read_count                           128                                                                    TRUE     FALSE      FALSE
_db_file_noncontig_mblock_read_count               11                                                                     TRUE     FALSE      FALSE
_db_file_optimizer_read_count                      8                                                                      TRUE     FALSE      FALSE
_sort_multiblock_read_count                        2                                                                      TRUE     FALSE      FALSE
 
SQL> alter system set db_file_multiblock_read_count=32;
 
System altered.
 
SQL> set echo off
SQL> @parms
Enter value for parameter: read_count
Enter value for isset: 
Enter value for show_hidden: Y
 
NAME                                               VALUE                                                                  ISDEFAUL ISMODIFIED ISSET
-------------------------------------------------- ---------------------------------------------------------------------- -------- ---------- ----------
db_file_multiblock_read_count                      32                                                                     TRUE     TRUE       TRUE
_db_file_exec_read_count                           32                                                                     TRUE     FALSE      FALSE
_db_file_noncontig_mblock_read_count               11                                                                     TRUE     FALSE      FALSE
_db_file_optimizer_read_count                      32                                                                     TRUE     FALSE      FALSE
_sort_multiblock_read_count                        2                                                                      TRUE     FALSE      FALSE
 
SQL> -- notice that _db_file_exec_read_count and _db_file_optimizer_read_count are now equal to each other
SQL>
SQL> -- let's try putting it back to 128
SQL>
SQL> alter system set db_file_multiblock_read_count=128;
 
System altered.
 
SQL> @parms
Enter value for parameter: read_count
Enter value for isset: 
Enter value for show_hidden: Y
 
NAME                                               VALUE                                                                  ISDEFAUL ISMODIFIED ISSET
-------------------------------------------------- ---------------------------------------------------------------------- -------- ---------- ----------
db_file_multiblock_read_count                      128                                                                    TRUE     TRUE       TRUE
_db_file_exec_read_count                           128                                                                    TRUE     FALSE      FALSE
_db_file_noncontig_mblock_read_count               11                                                                     TRUE     FALSE      FALSE
_db_file_optimizer_read_count                      128                                                                    TRUE     FALSE      FALSE
_sort_multiblock_read_count                        2                                                                      TRUE     FALSE      FALSE
 
SQL> -- notice that db_file_multiblock_read_count still shows up as being Set
SQL> -- also notice that _db_file_exec_read_count and _db_file_optimizer_read_count are still equal to each other
SQL> -- let's try bouncing just to be sure
SQL>
SQL> startup force
ORACLE instance started.
 
Total System Global Area 3113586688 bytes
Fixed Size                  1316204 bytes
Variable Size            1409288852 bytes
Database Buffers         1694498816 bytes
Redo Buffers                8482816 bytes
Database mounted.
Database opened.
SQL> 
SQL> @parms
Enter value for parameter: read_count
Enter value for isset: 
Enter value for show_hidden: Y
 
NAME                                               VALUE                                                                  ISDEFAUL ISMODIFIED ISSET
-------------------------------------------------- ---------------------------------------------------------------------- -------- ---------- ----------
db_file_multiblock_read_count                      128                                                                    FALSE    FALSE      TRUE
_db_file_exec_read_count                           128                                                                    TRUE     FALSE      FALSE
_db_file_noncontig_mblock_read_count               11                                                                     TRUE     FALSE      FALSE
_db_file_optimizer_read_count                      128                                                                    TRUE     FALSE      FALSE
_sort_multiblock_read_count                        2                                                                      TRUE     FALSE      FALSE
 
SQL> -- so Oracle still knows that db_file_multiblock_read_count has been set 
SQL> -- and while the db_file_multiblock_read_count is set to it's original default value, 
SQL> -- the hidden parameters that depend on it are not
SQL>
SQL> -- let's reset the parameter 
SQL> 
SQL> set echo on
SQL> @reset_parms
SQL> alter system reset &parameter_name  scope=spfile sid='*';
Enter value for parameter_name: db_file_multiblock_read_count
 
System altered.
 
SQL> set echo off
SQL> @parms
Enter value for parameter: read_count
Enter value for isset: 
Enter value for show_hidden: Y
 
NAME                                               VALUE                                                                  ISDEFAUL ISMODIFIED ISSET
-------------------------------------------------- ---------------------------------------------------------------------- -------- ---------- ----------
db_file_multiblock_read_count                      128                                                                    FALSE    FALSE      TRUE
_db_file_exec_read_count                           128                                                                    TRUE     FALSE      FALSE
_db_file_noncontig_mblock_read_count               11                                                                     TRUE     FALSE      FALSE
_db_file_optimizer_read_count                      128                                                                    TRUE     FALSE      FALSE
_sort_multiblock_read_count                        2                                                                      TRUE     FALSE      FALSE
 
SQL> -- have to bounce for the reset to take effect
SQL> 
SQL> startup force
ORACLE instance started.
 
Total System Global Area 3113586688 bytes
Fixed Size                  1316204 bytes
Variable Size            1409288852 bytes
Database Buffers         1694498816 bytes
Redo Buffers                8482816 bytes
Database mounted.
Database opened.
SQL> 
SQL> @parms
Enter value for parameter: read_count
Enter value for isset: 
Enter value for show_hidden: Y
 
NAME                                               VALUE                                                                  ISDEFAUL ISMODIFIED ISSET
-------------------------------------------------- ---------------------------------------------------------------------- -------- ---------- ----------
db_file_multiblock_read_count                      128                                                                    TRUE     FALSE      FALSE
_db_file_exec_read_count                           128                                                                    TRUE     FALSE      FALSE
_db_file_noncontig_mblock_read_count               11                                                                     TRUE     FALSE      FALSE
_db_file_optimizer_read_count                      8                                                                      TRUE     FALSE      FALSE
_sort_multiblock_read_count                        2                                                                      TRUE     FALSE      FALSE
 
SQL> -- note that Oracle no longer thinks the parameter has been set 
SQL> -- also note that the _db_file_optimizer_read_count parameter is back to it's default value of 8
SQL> 
SQL> exit