 create index tmp_pka_delete_idx on POSITION_KEEPING_ACCOUNT
 (physical_commodity, expiry_date, exchange_code, generic_contract_type);
