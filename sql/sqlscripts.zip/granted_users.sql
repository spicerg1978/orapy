set serveroutput on 
cl scr
prompt ================================
prompt ================================

prompt
prompt DISPLAY USERS VIA APPLICATION
prompt

prompt ================================
prompt ================================

set feedback on

prompt
ACCEPT app CHAR PROMPT    "Enter application name : "
prompt

variable x refcursor;

exec dbsecurity.granted_users('&app',:x);

print :x



