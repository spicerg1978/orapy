select s.sid,s.serial#,p.spid,p.pid,s.username,s.osuser
  from v$session s,v$process p
 where s.paddr=p.addr
   and sql_id in ('0573982m2q5cm','2hpaqsug13aqm','487ab3zzf3u9r','gnb4ah9s2jsmh','2g5n246gbcc3h');
   
   
