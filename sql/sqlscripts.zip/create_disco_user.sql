cl scr
set echo off verify off

Prompt
ACCEPT username CHAR PROMPT 'Enter name for new user:  '
Prompt

Prompt
ACCEPT pass hide CHAR PROMPT 'Enter password for new user:  ' 
Prompt

Prompt
Prompt creating database user...
Prompt

grant create session, discoverer_user to &username identified by &pass;
alter user &username default tablespace users temporary tablespace temp profile disco_user;

Prompt
Prompt setting quotas...
Prompt

set heading off feedback off verify off
spool quota.sql
select 'alter user &username quota 0 on '||tablespace_name||';' 
 from dba_tablespaces where tablespace_name != 'TEMP';
spool off
set feedback on heading on termout off
prompt set echo off feedback off
@quota.sql
set termout on



column username format a15 heading "Username"
column account_status format a15 heading "Status"
column lock_date format a10 heading "Lock date"
column expiry_date format a12 heading "Exp date"
column default_tablespace format a15 heading "Def tblsp"
column temporary_tablespace format a15 heading "Temp tblsp"
column created format a15 heading "Created"
column profile format a15 heading "Profile"
column user_id format 9,999,999 heading "id"
SELECT username, account_status, lock_date, expiry_date, default_tablespace, temporary_tablespace, created, profile, user_id 
  FROM dba_users 
 WHERE username =UPPER('&username');
 
Prompt
Prompt
Prompt existing in 5 seconds.....
Prompt

exec dbms_lock.sleep(5);

exit