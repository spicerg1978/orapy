select plan_table_output from table(dbms_xplan.display('PLAN_TABLE',null,'TYPICAL'));



alter system set pga_aggregate_target = 1g;



DECLARE
  name varchar2(50);
  version varchar2(3);
BEGIN
  select regexp_replace(version,'\..*') into version from v$instance;

  if version = '10' then
    execute immediate 
      q'[alter session set events '5614566 trace name context forever']'; -- bug fix for 10.2.0.4 backport
  end if;

  select address||','||hash_value into name
  from v$sqlarea 
  where sql_id like '9z93w0kwgtvg9';

  sys.dbms_shared_pool.purge(name,'C',1);

END;
/

select num_rows, sample_size
from dba_tables 
where table_name = 'T_AH_O_G_U';


select low_value, high_value, num_distinct,num_buckets,sample_size, histogram
from user_tab_col_statistics where table_name = 'HALF_TRADE' and column_name = 'KERD_TRADE_IND'

exec dbms_stats.gather_table_stats('TRIDGUI3','HALF_TRADE',method_opt=>'FOR ALL COLUMNS SIZE AUTO', estimate_percent=>100, cascade=>TRUE);