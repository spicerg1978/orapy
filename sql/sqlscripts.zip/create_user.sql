cl scr
set echo off verify off

Prompt
ACCEPT username CHAR PROMPT 'Enter name for new user:  '
Prompt
ACCEPT default_tblsp CHAR PROMPT 'Enter name for default tablespace:  '
Prompt
ACCEPT index_tblsp CHAR PROMPT 'Enter name for index tablespace:  '
Prompt
ACCEPT temp_tblsp CHAR PROMPT 'Enter name for temp tablespace:  '

Prompt
Prompt creating database user...
Prompt

create user &username identified by &username;
grant connect, resource to &username;


Prompt
Prompt changing password...
Prompt

passw &username


Prompt
Prompt setting tablespaces...
Prompt

alter user &username default tablespace &default_tblsp temporary tablespace &temp_tblsp;

Prompt
Prompt setting quotas...
Prompt

set heading off feedback off verify off
spool quota.sql
select 'alter user &username quota 0 on '||tablespace_name||';' from dba_tablespaces where tablespace_name !='TEMP';
spool off
set feedback on heading on termout off
prompt set echo off feedback off
@quota.sql
set termout on

revoke unlimited tablespace from &username; 
alter user &username quota 10M on &default_tblsp;
alter user &username quota 10M on &index_tblsp;

Prompt
Prompt setting role...
Prompt


Prompt ######################################################
Prompt ##
Prompt ## Is the new schema a users of:
Prompt ## 
Prompt ## 1. discoverer
Prompt ## 2. an application owner
Prompt ## 3. dba 
Prompt ## 4. none of the above
Prompt ## 
Prompt ## NB: default is 'none of the above'
Prompt ## ENTER to continue ^c to exit...
Prompt ######################################################

ACCEPT schema CHAR PROMPT 'Schema type:  '
set verify off

declare


v_schema varchar2(10) :='&schema';


begin


	if     v_schema ='1'
	  then execute immediate 'grant discoverer_user to &username';
	       execute immediate 'alter user &username profile disco_user';
	elsif  v_schema ='2' 
	  then execute immediate 'grant live_app to &username';
	       execute immediate 'grant select any table to &username';
	elsif  v_schema ='3' 
	  then execute immediate 'grant dba to &username';	 
	  else NULL;
	end if;

end;
/

set lines 1000
column username format a15 heading "Username"
column account_status format a15 heading "Status"
column lock_date format a10 heading "Lock date"
column expiry_date format a12 heading "Exp date"
column default_tablespace format a15 heading "Def tblsp"
column temporary_tablespace format a15 heading "Temp tblsp"
column created format a15 heading "Created"
column profile format a15 heading "Profile"
column user_id format 9,999,999 heading "id"
SELECT username, account_status, lock_date, expiry_date, default_tablespace, temporary_tablespace, created, profile, user_id 
  FROM dba_users 
 WHERE username =UPPER('&username');



