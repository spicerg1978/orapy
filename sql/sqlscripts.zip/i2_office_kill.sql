clear breaks
clear columns
clear screen
column code format a4

-- list offices

select long_name, code 
  from maj_locations
 order by long_name;

-- prompt for code

prompt
ACCEPT office CHAR PROMPT    "Enter office code to kill : "
prompt

set heading off feedback off verify off echo off termout off

spool kill_office.sql

select 'alter system kill session '||''''||s.sid||','||s.serial#||''''||';'
  from  v$session s,  bus_roles b, v$process p
 where  UPPER('OPS$' || b.login_name) = s.username
   and  s.paddr = p.addr
   and  b.maj_loc_code_at  in ('&office');   

spool off

@@kill_office.sql

set heading on feedback on verify off termout on