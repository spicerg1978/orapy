column os_username format a20
column username    format a20
column userhost    format a20
column terminal    format a20
column when   	   format a24
column owner       format a20
column obj_name    format a20
column action      format a20
column action_name format a20     
column returncode  format 99999
column priv_used   format a20
select
os_username,
username,  
userhost,  
terminal,  
to_char(timestamp, 'DD-MON-YYYY hh24:mi:ss') when,  
owner,  
obj_name,  
action,  
action_name,          
statementid,  
returncode,  
priv_used
from dba_audit_trail;