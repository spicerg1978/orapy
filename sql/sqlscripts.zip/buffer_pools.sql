select *
  from user_tab_columns dtc,
       user_tab_paritions utp
  where utc.table_name = utp.table_name
    and utp.table_name = 'GJS1'
    
    
    --A view for getting an objects buffer_ pool defaults: 
    
    CREATE OR REPLACE VIEW OCI_BUFFER_POOLS AS
    select t.owner object_owner, table_name object, buffer_pool from dba_tables t
       where buffer_pool is not null
    union
    select tabp.table_owner ,  table_name object, buffer_pool
      from dba_tab_partitions tabp where buffer_pool is not null
    union
    select tabsp.table_owner, table_name object, buffer_pool
       from dba_tab_subpartitions tabsp where buffer_pool is not null
    union
    select i.owner, index_name object, buffer_pool
       from dba_indexes i where buffer_pool is not null
    union
    select ip.index_owner, index_name object, buffer_pool
      from dba_ind_partitions ip where buffer_pool is not null
    union
    SELECT ips.index_owner, index_name object, buffer_pool
       from dba_ind_subpartitions ips where buffer_pool is not null
;
    

    
    A view to select the objects and types in the buffer cache:
    
    create or replace view oci_block_header as 
    -- For performance, queries against this view should use cost based optimizer 
    select b.indx,             -- Entry in buffer cache 
           b.hladdr,           -- ADDR of v$latch_children entry for cache buffer chain latch 
           b.ts# tblspace,     -- Tablespace id 
           b.file# fileid,     -- File id 
           b.dbablk blockid,   -- Block id 
           b.obj objid,        -- Object id 
           u.name owner,       -- Object owner 
           o.name object_name,       -- Object name 
           o.subname subobject_name, -- Subobject name 
           decode (o.type#, 
                     1, 'INDEX', 
                     2, 'TABLE', 
                     3, 'CLUSTER', 
                    19, 'TABLE PARTITION', 
                    20, 'INDEX PARTITION', 
                    21, 'LOB', 
                    34, 'TABLE SUBPARTITION', 
                    35, 'INDEX SUBPARTITION', 
                    39, 'LOB PARTITION', 
                    40, 'LOB SUBPARTITION', 
                        'UNDEFINED' 
                  ) object_type  -- Object type 
    from x$bh b, obj$ o, user$ u 
    where b.obj = o.dataobj# 
    and   o.owner# = u.user# 
    / 
    
    And a view to merge the information together and give me the information I want.
    
      
    CREATE OR REPLACE VIEW OCI_BUFFER_CACHE_USE  AS
    select a.owner, a.object_name, a.object_type, count(a.object_name) blocks#, b.buffer_pool
    from oci_block_header a, oci_buffer_pools b
    where owner not in ( 'SYS', 'SYSTEM', 'PERFSTAT')
    and a.object_name = b.OBJECT AND a.owner = b.object_owner
    group by b.buffer_pool, a.owner, a.object_type, a.object_name
    -- having count(a.object_name) > 100    -- if you don't want small objects
; 