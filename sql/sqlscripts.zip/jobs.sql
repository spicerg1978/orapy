set linesize 250
col log_user		for a15		head 'User'
col job			for 9999999 	head 'Job'
col broken 		for a1 		head 'B'
col failures 		for 99 		head 'fail'
col last_date 		for a18 	head 'Last|Date'
col this_date 		for a18 	head 'This|Date'
col next_date 		for a18 	head 'Next|Date'
col interval 		for 9999.0000 	head 'Run|Interval'
col what 		for a60 	head 'Job'

select 	j.log_user,
	j.broken,
	j.failures,
	j.last_date||':'||j.last_sec  last_date,
	j.this_date||':'||j.this_sec  this_date,
	j.next_date||':'||j.this_sec  next_date,
	j.next_date - j.last_date interval,
	j.what
  from	(select dj.log_user, dj.job, dj.broken, dj.failures, dj.last_date,
                dj.last_sec, dj.this_date, dj.this_sec, dj.next_date, dj.next_sec,
                dj.interval, dj.what
           from dba_jobs dj) j;