spool compare_tri_con_trades.out
exec dba_admin.trunc_tables;
commit;

insert into  dba_admin.connect_trades
SELECT 'FN', t.matched_trade_id, t.exchange_code, t.physical_commodity, 
       b_slips.TERMINAL_ID||substr('000000',1,6-length(b_slips.SLIP_ID))||b_slips.SLIP_ID,
       s_slips.TERMINAL_ID||substr('000000',1,6-length(s_slips.SLIP_ID))||s_slips.SLIP_ID
FROM trade_info@pssp10 t , half_trade@pssp10 buy , half_trade@pssp10 sell , slip_ids@pssp10 b_slips , slip_ids@pssp10 s_slips 
where t.BUY_HALF_TRADE_ID = buy.HALF_TRADE_ID and t.SELL_HALF_TRADE_ID = sell.HALF_TRADE_ID 
and b_slips.HALF_TRADE_ID(+) = buy.HALF_TRADE_ID and s_slips.HALF_TRADE_ID(+) = sell.HALF_TRADE_ID 
and t.state in (2) and t.volume <> 0;
commit;

insert into  dba_admin.connect_trades
SELECT 'EQ', t.matched_trade_id, t.exchange_code, t.physical_commodity, 
       b_slips.TERMINAL_ID||substr('000000',1,6-length(b_slips.SLIP_ID))||b_slips.SLIP_ID,
       s_slips.TERMINAL_ID||substr('000000',1,6-length(s_slips.SLIP_ID))||s_slips.SLIP_ID
FROM trade_info@pssp40 t , half_trade@pssp40 buy , half_trade@pssp40 sell , slip_ids@pssp40 b_slips , slip_ids@pssp40 s_slips 
where t.BUY_HALF_TRADE_ID = buy.HALF_TRADE_ID and t.SELL_HALF_TRADE_ID = sell.HALF_TRADE_ID 
and b_slips.HALF_TRADE_ID(+) = buy.HALF_TRADE_ID and s_slips.HALF_TRADE_ID(+) = sell.HALF_TRADE_ID 
and t.state in (2) and t.volume <> 0;
commit;

set heading on;
set feedback on;
set echo on;
set verify on;
set term on;

set lines 120;
set pages 1024;
set numwidth 32;
spool fn_miss_trades.out
select exchange_code, physical_commodity, matched_trade_id, buy_half_trade_id BUY, sell_half_trade_id SELL from dba_admin.connect_trades c1
where not exists (select '1' from  tridlive.half_trade c2
where c1.buy_half_Trade_id = c2.half_trade_id
and c2.trading_day =  dba_admin.manage_partitions.get_trading_day('TRIDLIVE'))
and c1.exchange = 'FN';
spool off
commit;

spool eq_miss_trades.out
select exchange_code, physical_commodity, matched_trade_id, buy_half_trade_id BUY, sell_half_trade_id SELL from dba_admin.connect_trades c1
where not exists (select '1' from  tridlive.half_trade c2
where c1.buy_half_Trade_id = c2.half_trade_id
and c2.trading_day =  dba_admin.manage_partitions.get_trading_day('TRIDLIVE'))
and c1.exchange = 'EQ';
spool off
commit;
