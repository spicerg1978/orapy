--set feedback off trims on pages 1000 lines 1000 heading off verify off
prompt
accept business_date date prompt    "Enter business_date : "
prompt

spool c:\dataload.csv
select
	object_owner											||','||
	object_name											||','||
	business_date											||','||
	to_char(start_time, 'HH24:MI:SS')								||','||
	to_char(end_time, 'HH24:MI:SS')									||','||
	trunc( 24 * ( ((end_time-start_time) - trunc(end_time-start_time)) ))				||','||
	trunc( 60 * ( ((end_time-start_time) * 24) - (trunc((end_time-start_time) * 24)) ))		||','|| 
        round(60 * ( ((end_time-start_time) * 1440) - (trunc((end_time-start_time) * 1440)) )) 
  from datamart_stats.dataload_stats
 where business_date = '&business_date'
 order by start_time;
spool off

edit c:\dataload.csv