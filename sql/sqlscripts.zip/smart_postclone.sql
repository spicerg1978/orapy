
create or replace directory BFM_EIU_EXTRACT as '/wload/dp3t/home/dp3tsmrt/smart_files/out/edostar_extract';
create or replace directory CIDNEECOMPLIANCEDIR as '/wload/dp3t/home/dp3tsmrt/smart_files/out/compliance';
create or replace directory COMPLIANCEDIR as '/wload/dp3t/home/dp3tsmrt/smart_files/out/compliance';
create or replace directory DPR_DAILY_TRANS as '/wload/dp3t/home/dp3tsmrt/smart_files/out/dpr_daily_trans/';
create or replace directory DPR_MONTHLY_STATS as '/wload/dp3t/home/dp3tsmrt/smart_files/out/dpr_monthly_stats/';
create or replace directory DPR_ADV_SUMMARY as '/wload/dp3t/home/dp3tsmrt/smart_files/out/dpr_adv_summary/';
create or replace directory DPR_BFM_EOM as '/wload/dp3t/home/dp3tsmrt/smart_files/out/dpr_bfm_mon/';
create or replace directory BFM_MONTHLY_TGT_EXTRACT as '/wload/dp3t/home/dp3tsmrt/smart_files/out/mon_targets_extract/';
create or replace directory VAPM_CORE_EXCEPTION as '/wload/dp3t/home/dp3tsmrt/smart_files/out/vapm/core/exception';
create or replace directory VAPM_CORE_MONTHLY as '/wload/dp3t/home/dp3tsmrt/smart_files/out/vapm/core/monthly';
create or replace directory VAPM_CORE_WEEKLY as '/wload/dp3t/home/dp3tsmrt/smart_files/out/vapm/core/weekly';
create or replace directory VAPM_CONQUEST_EXCEPTION as '/wload/dp3t/home/dp3tsmrt/smart_files/out/vapm/conquest/exception';
create or replace directory VAPM_CONQUEST_DAILY as '/wload/dp3t/home/dp3tsmrt/smart_files/out/vapm/conquest/daily';
