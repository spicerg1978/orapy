select app_owner "Application", round(24*60*gap) "Downtime"
  from
(
select  app_owner,
	to_date(to_char(max(end_time), 'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') -
	to_date(to_char(min(start_time), 'YYYY-MM-DD HH24:MI:SS'),'YYYY-MM-DD HH24:MI:SS') gap
  from
	(select * 
	   from datamart_stats.dataload_config
	  where app_owner in (select distinct app_owner 
				from datamart_stats.dataload_config)
	) b,
	(select * 
	   from datamart_stats.dataload_stats
	  where trunc(business_date) = '&business_date'
	) a
 where b.object_owner = a.object_owner(+)
   and b.object_name = a.object_name(+)
group by app_owner
);
