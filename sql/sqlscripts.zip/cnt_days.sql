break on "Day" skip 1 on "User"

 select  to_char(timestamp, 'yyyy-mm-dd') "Day",
         USERNAME "User",
         count(*) "connects"
    from user_audit 
group by cube(to_char(timestamp, 'yyyy-mm-dd'), username)
order by 1,3,2;