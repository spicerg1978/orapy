select segment_name, sum((bytes)/(1024*1024)) as tbsize
 from dba_extents
where segment_type like 'TABLE%'
and owner = 'TRIDlive'
group by segment_name
order by 1
/



select segment_name, PARTITION_NAME, (bytes)/(1024*1024) as PART_SIZE
 from dba_extents
where segment_type like 'TABLE PARTITION'
and owner = 'TRIDlIVE'
--group by segment_name
order by 1
/




select segment_name, max(part_size)
   from (
 select segment_name, PARTITION_NAME, count(*) part_count--sum((bytes)/(1024*1024)) as PART_SIZE
     from dba_extents
    where segment_type like 'TABLE PARTITION'
    and owner = 'TRIDLIVE'
    a
    group by segment_name, PARTITION_NAME
  )
group by segment_name
/



alter system set db_cache_size=5G scope=spfile;

ALTER SYSTEM SET memory_max_target = 16G SCOPE=SPFILE;

ALTER SYSTEM SET memory_target = 16G scope=both;



select
      object_name       c1,
      object_type       c2,
      num_blocks        c3,
      (num_blocks/decode(sum(blocks), 0, .001, sum(blocks)))*100 c4
 from
      (select o.object_name object_name, o.object_type    object_type, count(1) num_blocks
         from dba_objects  o,
              v$bh bh
         where o.object_id  = bh.objd
           and o.owner  in ('TRIDLIVE')
         group by o.object_name, o.object_type
         order by count(1) desc) t1,
      dba_segments s
 where s.segment_name = t1.object_name
   and num_blocks > 10
   group by
      object_name,
      object_type,
      num_blocks
   order by
      num_blocks desc
/


 select name, block_size, SIZE_FOR_ESTIMATE, SIZE_FACTOR, ESTD_PHYSICAL_READS, ESTD_PCT_OF_DB_TIME_FOR_READS
 from  v$db_cache_advice;


