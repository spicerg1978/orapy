CREATE TABLE DELETED_QUERY
(
 QUERY_ID	NUMBER,
 DELETED_DATE	DATE
)
PARTITION BY RANGE (DELETED_DATE)
INTERVAL (NUMTODSINTERVAL(1,'day'))
(PARTITION p_first VALUES LESS THAN ('01-JAN-2011'));


create index del_qry_idx on DELETED_QUERY (query_id);


CREATE OR REPLACE TRIGGER QUERY_DELETE_TRG
 AFTER DELETE
 ON QUERY_MANAGER
 FOR EACH ROW
  DECLARE
  BEGIN

   -- Insert record into deleted_query table
   INSERT INTO DELETED_QUERY
   (QUERY_ID, DELETED_DATE)
   VALUES(:old.query_id,sysdate);

END;
/

CREATE OR REPLACE PROCEDURE QUERY_MANAGER_HOUSEKEEPING
(p_process_orphans     IN  VARCHAR2)
AS
   BEGIN

      -- Delete records from the query manager table where all records have been processed
      QUERY_MANAGER_DEL_PARENT;
      
      IF (p_process_orphans = 'TRUE') THEN
      
      -- orphaned results records also needed to be removed (because referential integrity is disabled)
      QUERY_MANAGER_DEL_CHILD;
      
      END IF;
      
 END QUERY_MANAGER_HOUSEKEEPING;
 
 
 CREATE OR REPLACE PROCEDURE QUERY_MANAGER_DEL_PARENT
 AS
    BEGIN
 
 
       -- Delete records from the query manager table where all records have been processed
      DELETE FROM query_manager WHERE last_row_retrieved=max_row;
      
      COMMIT;
       
 END QUERY_MANAGER_DEL_PARENT;
 
 
 CREATE OR REPLACE PROCEDURE QUERY_MANAGER_DEL_CHILD

    BEGIN
 
 -- Delete orphaned trade results
    DELETE 
      FROM half_trade_results 
     WHERE query_id IN (SELECT query_id 
                          FROM DELETED_QUERY);
    
    -- Delete orphaned notification results
    DELETE 
      FROM notification_results 
     WHERE query_id IN (SELECT query_id 
                          FROM DELETED_QUERY);
  
    -- Delete orphaned message_audit results
    DELETE 
      FROM tcsc_audit_results 
     WHERE query_id IN (SELECT query_id 
                          FROM DELETED_QUERY);
                          
    -- Delete orphaned position keeping account results
    DELETE 
      FROM pka_results 
     WHERE query_id IN (SELECT query_id 
                          FROM DELETED_QUERY);
                          
    -- Delete orphaned delivery pending account results
    DELETE 
      FROM dpa_results 
     WHERE query_id IN (SELECT query_id 
                          FROM DELETED_QUERY);
                          
    -- Delete orphaned series with long position results
    DELETE 
      FROM selp_results 
     WHERE query_id IN (SELECT query_id 
                          FROM DELETED_QUERY);
                          
    -- Delete orphaned commodities with expiring position results
    DELETE 
      FROM cep_results 
     WHERE query_id IN (SELECT query_id 
                          FROM DELETED_QUERY);
     
     COMMIT;
      
 END QUERY_MANAGER_DEL_CHILD;

      

