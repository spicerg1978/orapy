select tch, file#, dbablk
  from x$bh
 where (dbablk,file#) in
       (select dbms_rowid.rowid_block_number(rowid),
               dbms_rowid.rowid_to_absolute_fno(rowid,'TRIDLIVE','HALF_TRADE')
          from dual)
   and state = 1
/


select segment_name, max(part_size)
       from (
     select segment_name, PARTITION_NAME, sum((bytes)/(1024*1024)) as PART_SIZE
         from dba_extents
        where segment_type like 'TABLE PARTITION'
        and owner = 'TRIDLIVE'
        group by segment_name, PARTITION_NAME
      )
    group by segment_name
 /



select segment_name, max(part_size)
       from (
     select segment_name, sum((bytes)/(1024*1024)) as PART_SIZE
         from dba_extents
        where segment_type like 'TABLE'
        and owner = 'TRIDLIVE'
        group by segment_name 
      )
    group by segment_name
 /
