prompt
ACCEPT owner CHAR PROMPT "Enter owner : "
prompt 

spool grants.txt
 
 select 'grant '||privilege||' on '||lower(owner)||'.'||
         lower(table_name)||' to '||grantee||
         decode(grantable,'YES',' with grant option',NULL)||
         ' ;' grants
 from   sys.dba_tab_privs
 where  grantee      = upper('&&owner')
 order by grantee, privilege ;

spool off
 
edit grants.txt
/
