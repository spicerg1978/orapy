CREATE TABLE scott.test_table ( part_key number )
PARTITION BY RANGE (part_key) INTERVAL(10)
( PARTITION p0 VALUES LESS THAN (10) )
;
 
ALTER TABLE scott.test_table ADD CONSTRAINT pk_test_table PRIMARY KEY (part_key) USING INDEX LOCAL;
 
 
insert into scott.test_table values(2); 
insert into scott.test_table values(4); 
insert into scott.test_table values(6); 
 
insert into scott.test_table values(12); 
insert into scott.test_table values(14); 
insert into scott.test_table values(16); 
 
insert into scott.test_table values(102); 
insert into scott.test_table values(104); 
insert into scott.test_table values(106); 

insert into scott.test_table values(502); 
insert into scott.test_table values(504); 
insert into scott.test_table values(506); 

commit

select count(*), partition_name
from dba_tab_partitions
where table_name = 'TEST_TABLE'
 group by partition_name 
 order by 2