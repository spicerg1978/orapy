
declare 
 v_cnt number := 100;

BEGIN
  
  
  for x in 1000..1010 loop
   

INSERT INTO half_trade_results 
SELECT  v_cnt +1, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
  	 				FROM OPERATOR_GROUP 
  	 			       WHERE EXCHANGE_CODE = 'L' 
  	 			         AND TRADING_DAY = 7585 
  	 			         AND GROUP_NAME = 'TFIM' 
  	 			         AND FIRM != '***') 
           AND EXCHANGE_CODE='L' 
           AND TRADING_DAY = 007585 
           AND TRADE_STATUS IN ('UR'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
SELECT /*+ opt_param('optimizer_index_cost_adj',20) */ v_cnt +2, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
  	 				FROM OPERATOR_GROUP 
  	 			       WHERE EXCHANGE_CODE = 'L' 
  	 			         AND TRADING_DAY = 7585 
  	 			         AND GROUP_NAME = 'TFIM' 
  	 			         AND FIRM != '***') 
  	   AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND ORIGINATOR_FIRM = 'ODD' 
  	   AND TRADE_STATUS IN ('RT'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
SELECT  v_cnt +3, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN ('FBB','HLG','JLG','JPM','MFI','NKP') 
  	   AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND TRADE_STATUS IN ('UR'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
SELECT  v_cnt +12, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
 			        FROM OPERATOR_GROUP 
 			       WHERE EXCHANGE_CODE = 'L' 
 			       	 AND TRADING_DAY = 7585 
 			       	 AND GROUP_NAME = 'OFIM' 
 			       	 AND FIRM != '***') 
   AND EXCHANGE_CODE='L' 
   AND TRADING_DAY = 007585 
   AND ORIGINATOR_FIRM = 'DGO' 
   AND TRADE_STATUS IN ('NC'))) 
 ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;
 

INSERT INTO half_trade_results 
SELECT  v_cnt +4, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN ('BTA','CDN','ITG','IVZ','LYV','MAN','TCG','TRC','VGA') 
  	   AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND TRADE_STATUS IN ('UR'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
SELECT /*+ opt_param('optimizer_index_cost_adj',20) */ v_cnt +5, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN ('AAP') 
  	   AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND TRADE_STATUS IN ('RT'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
SELECT  v_cnt +6, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
  	 				FROM OPERATOR_GROUP 
  	 			       WHERE EXCHANGE_CODE = 'L' 
  	 			         AND TRADING_DAY = 7585 
  	 			         AND GROUP_NAME = '$GSF' 
  	 			         AND FIRM != '***') 
          AND EXCHANGE_CODE='L' 
          AND TRADING_DAY = 007585 
          AND TRADE_STATUS IN ('UR'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
SELECT /*+ opt_param('optimizer_index_cost_adj',20) */ v_cnt +7, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
  	 				FROM OPERATOR_GROUP 
  	 			       WHERE EXCHANGE_CODE = 'L' 
  	 			         AND TRADING_DAY = 7585 
  	 			         AND GROUP_NAME = 'TFIM' 
  	 			         AND FIRM != '***') 
  	   AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND TRADE_STATUS IN ('RT'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
 SELECT  v_cnt +8, rownum AS query_row_num, ht.* 
   FROM (SELECT * 
   	   FROM half_trade 
   	  WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
   	  				 FROM OPERATOR_GROUP 
   	  				WHERE EXCHANGE_CODE = 'L' 
   	  				  AND TRADING_DAY = 7585 
   	  				  AND GROUP_NAME = 'OFIM' 
   	  				  AND FIRM != '***') 
   	    AND EXCHANGE_CODE='L' 
   	    AND TRADING_DAY = 007585 
   	    AND ORIGINATOR_FIRM = 'TNW' 
   	    AND TRADE_STATUS IN ('UA'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;


INSERT INTO half_trade_results 
SELECT /*+ opt_param('optimizer_index_cost_adj',20) */ v_cnt +8, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
 WHERE (( ORIGINATOR_FIRM IN ('BTA','CDN','ITG','IVZ','LYV','MAN','TCG','TRC','VGA') 
   AND EXCHANGE_CODE='L' AND TRADING_DAY = 007585 AND TRADE_STATUS IN ('RT'))) 
 ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;
 

INSERT INTO half_trade_results 
SELECT :p_query_id, rownum AS query_row_num, ht.* 
  FROM (SELECT * 
  	  FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
  	 				FROM OPERATOR_GROUP 
  	 			       WHERE EXCHANGE_CODE = 'L' 
  	 			         AND TRADING_DAY = 7585 
  	 			         AND GROUP_NAME = '$BPB' 
  	 			         AND FIRM != '***') 
	   AND EXCHANGE_CODE='L' 
	   AND TRADING_DAY = 007585 
	   AND TRADE_STATUS IN ('UR'))) 
 ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;
 
 
INSERT INTO half_trade_results 
SELECT  :p_query_id, rownum AS query_row_num, ht.* 
  FROM (SELECT * 
  	  FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
  	 				FROM OPERATOR_GROUP 
  	 			       WHERE EXCHANGE_CODE = 'L' 
  	 			       	 AND TRADING_DAY = 7585 
  	 			       	 AND GROUP_NAME = 'TFIM' 
  	 			       	 AND FIRM != '***') 
  	   AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND ORIGINATOR_FIRM = 'AWZ' 
  	   AND TRADE_STATUS IN ('UR'))) 
  ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;
  
INSERT INTO half_trade_results 
SELECT /*+ opt_param('optimizer_index_cost_adj',20) */ v_cnt +9, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN (SELECT FIRM 
  	 			        FROM OPERATOR_GROUP 
  	 			       WHERE EXCHANGE_CODE = 'L' 
  	 			         AND TRADING_DAY = 7585 
  	 			         AND GROUP_NAME = '$FCW' 
  	 			         AND FIRM != '***') 
  	  AND EXCHANGE_CODE='L' 
  	  AND TRADING_DAY = 007585 
  	  AND TRADE_STATUS IN ('RT'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;

INSERT INTO half_trade_results 
SELECT  v_cnt +10, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( 1 = 1  AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND TRADE_STATUS IN ('UR'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;


INSERT INTO half_trade_results 
SELECT  v_cnt +11, rownum AS query_row_num, ht.* 
  FROM (SELECT * FROM half_trade 
  	 WHERE (( ORIGINATOR_FIRM IN ('AUK','IAW','LBV','RBI','TDN','UBS') 
  	   AND EXCHANGE_CODE='L' 
  	   AND TRADING_DAY = 007585 
  	   AND TRADE_STATUS IN ('UR'))) 
ORDER BY half_trade_id, sub_trade_seq_no, trading_day, exchange_code, slip_type ) ht WHERE rownum <= 100 + 1;


end loop;
end;
/
