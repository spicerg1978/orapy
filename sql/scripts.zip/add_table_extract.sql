 set lines 1000 pages 1000
 
 prompt *************************************************
 prompt *	add_table script			*
 prompt *************************************************
 
 prompt
  ACCEPT own CHAR PROMPT    "Enter Table Owner: "
 prompt
 
 prompt
  ACCEPT tab CHAR PROMPT    "Enter Table Name: "
 prompt
 

insert into conf
select owner, table_name, column_name, column_id, 'Y'
  from dba_tab_columns
 where owner = '&own'
   and table_name = '&tab';

commit;

select *
  from conf
 where table_owner = '&own'
   and table_name = '&tab'
order by col_num;



 