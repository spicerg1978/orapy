set verify off
col "Owner" 	format a20
col "Name"  	format a30
col "Bus_Date" 	format a15
col "Start"	format a10
col "End"	format a10
col "Elapsed"   format a20
column "Hrs" 	format 		999
column "Min" 	format 		999
column "Sec" 	format 		999

prompt
accept business_date date prompt    "Enter business_date : "
prompt

select
	object_owner	"Owner",
	object_name	"Name",
	business_date	"Bus_Date",
	to_char(start_time, 'HH24:MI:SS')	"Start",
	to_char(end_time, 'HH24:MI:SS')		"End",
	trunc( 24 * ( ((end_time-start_time) - trunc(end_time-start_time)) )) "Hrs", 
	trunc( 60 * ( ((end_time-start_time) * 24) - (trunc((end_time-start_time) * 24)) )) "Min", 
        60 * ( ((end_time-start_time) * 1440) - (trunc((end_time-start_time) * 1440)) ) "Sec" 
  from datamart_stats.dataload_stats
 where business_date = '&business_date'
 order by start_time;
 
prompt 
prompt Total elapsed minutes for load...
prompt

set heading off
 
select sum (
       trunc( 60 * ( ((end_time-start_time) * 24) - (trunc((end_time-start_time) * 24)) ))
       ) "Total Mins"
  from datamart_stats.dataload_stats
 where business_date = '&business_date';   
 
prompt

set heading on