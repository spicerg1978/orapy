select  to_char(ASS2.parent_party_id) ,
        ATT1.VALUE AS ACCOUNTSETNAME,
        ATT2.VALUE AS GROUPNAME,
        PV.STATE,
        PV.WKF_STATE,
        p.productnumber,
        p.sortcode,
        ppu.to_date,
  from portal_owner.party_product_usage ppu, portal_owner.product p,
       portal_owner.association ass1, portal_owner.association ass2,
       portal_owner.attribute att1, portal_owner.attribute att2,
       portal_owner.profile_version pv
 where ppu.product_id = p.id
   and ppu.party_id = ass1.child_party_id
   and ass2.CHILD_PARTY_ID = ass1.PARENT_PARTY_ID
   and ass1.CHILD_PARTY_ID = att1.party_id
   and ass1.parent_party_id = att2.party_id
   and ass1.child_party_id = pv.party_id
   and ASS1.ASSOCIATION_TYPE = 'HASPRODUCTSET'
   and ASS1.TO_DATE is null
   and ASS2.ASSOCIATION_TYPE = 'HASPRODUCTSETGROUP'
   and ASS2.TO_DATE is null
   and ASS2.PARENT_PARTY_ID = 12912720001
   and ATT1.TO_DATE is null
   and PV.TO_DATE IS NULL
   and ATT1.VALUE != 'UNALLOCATED'
   and p.productnumber = '30417610'
   