set serveroutput on 
cl scr
prompt ================================
prompt ================================

prompt
prompt DISPLAY APPLICATIONS AUTHORISED BY USER
prompt

prompt ================================
prompt ================================

set feedback on

prompt
ACCEPT usr CHAR PROMPT    "Enter user name : "
prompt

variable x refcursor;

exec dbsecurity.granted_apps('&usr',:x);

print :x



