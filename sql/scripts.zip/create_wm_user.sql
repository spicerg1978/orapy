cl scr
set echo off verify off

Prompt
ACCEPT username CHAR PROMPT 'Enter name for new user:  '
Prompt
--ACCEPT pwd CHAR PROMPT 'Enter password for &username: '
--prompt
Prompt creating database user...
Prompt

create user &username identified by hello default tablespace i2_tools temporary tablespace temp_space profile default account unlock;

Prompt
Prompt granting access to user...
grant create session to &username;
GRANT front_office TO &username;
GRANT i2_gen_role TO &username;
GRANT BACK_OFFICE TO &username;
GRANT CASH_MANAGEMENT TO &username;
GRANT CHARITIES_AND_PENSIONS TO &username;
GRANT CSD_NOTES TO &username;
GRANT FEES_ENQ TO &username;
GRANT FRONT_OFFICE TO &username;
GRANT GM_FRONT_OFFICE TO &username;
GRANT I2_GEN_ROLE TO &username;
GRANT MAN_INFO TO &username;
GRANT NOMINEE_TV TO &username;
GRANT NOM_TRFRS_ENQ TO &username;
GRANT PORTFOLIO_REPORTS TO &username;
GRANT POSTINGS TO &username;
GRANT STANDARD_USER TO &username;
GRANT UPLOAD TO &username;
GRANT UPLOAD_CERTS TO &username;
GRANT USERS TO &username;


set lines 1000
column username format a15 heading "Username"
column account_status format a15 heading "Status"
column lock_date format a10 heading "Lock date"
column expiry_date format a12 heading "Exp date"
column default_tablespace format a15 heading "Def tblsp"
column temporary_tablespace format a15 heading "Temp tblsp"
column created format a15 heading "Created"
column profile format a15 heading "Profile"
column user_id format 9,999,999 heading "id"
SELECT username, account_status, lock_date, expiry_date, default_tablespace, temporary_tablespace, created, profile, user_id 
  FROM dba_users 
 WHERE username =UPPER('&username');



