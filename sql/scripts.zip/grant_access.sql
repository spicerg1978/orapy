prompt ==========================
prompt ==========================

Prompt
Prompt G R A N T   A C C E S S
Prompt
Prompt 
Prompt This program grants access to a user / program
Prompt
Prompt
Prompt

prompt ==========================
prompt ==========================

set feedback on

prompt
ACCEPT username CHAR PROMPT    "Enter user name (UPPERCASE): "
prompt

prompt
ACCEPT program CHAR PROMPT "Enter program name : "
prompt

prompt
ACCEPT desc CHAR PROMPT  "Enter program description : "
prompt

prompt 
pause  Granting &username access for &desc, program name &program press RETURN to continue....

exec dbsecurity.add_user_program('&username', '&program', '&desc');

set verify off
prompt
prompt Access now granted for &username
prompt 

break on user skip 1 on user
select valid_ora "User", valid_program "Executable", description "Program"
  from valid_users
 where valid_ora ='&username'
 order by 1,2,3;
 
 