SET HEADING OFF FEEDBACK ON VERIFY OFF

select username, osuser, status, machine, sid, serial#,
       to_char(logon_time, 'YYYY-MM-DD HH24:MI:SS') "LOGIN", 
       module, action, client_info
  from v$session
 where username is not null
 and sid != (select distinct sid from v$mystat)
 order by logon_time;

select 'alter system kill session '||''''||sid||','||serial#||''''||';'
from v$session 
where username =UPPER('&name') AND STATUS != 'KILLED';

