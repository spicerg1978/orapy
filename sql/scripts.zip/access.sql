break on user skip 1 on user

prompt
ACCEPT username CHAR PROMPT    "Enter username : "
prompt

select valid_ora "User", valid_program "Executable", description "Program"
  from valid_users
 where upper(valid_ora) like upper('&username')
 order by 1,2,3;