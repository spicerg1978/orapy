 set lines 1000 pages 1000
 
 prompt *************************************************
 prompt *	add_table script			*
 prompt *************************************************
 
 prompt
  ACCEPT own CHAR PROMPT    "Enter Table Schema: "
 prompt
 
begin

for x in (select table_name from dba_tables where owner = '&own') loop

insert into conf
select owner, table_name, column_name, column_id, 'Y'
  from dba_tab_columns
 where owner = '&own'
   and table_name = x.table_name;

commit;

end loop;
end;
/

select *
  from conf
 where table_owner = '&own'
 order by col_num;



 